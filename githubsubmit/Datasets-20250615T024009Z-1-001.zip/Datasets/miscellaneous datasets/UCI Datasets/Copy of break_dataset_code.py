import pandas as pd

df = pd.read_csv('heart_disease_uci_with_null_data2.csv')
import pandas as pd

# Sample data


# Filter the DataFrame based on certain values
new_df = df[df['dataset'] == 'Cleveland']

# Create a new CSV file
new_df.to_csv('Cleveland_new_data.csv', index=False)

print(new_df)

new_df2 = df[df['dataset'] == 'Hungary']

# Create a new CSV file
new_df2.to_csv('Hungary_new_data.csv', index=False)

new_df3 = df[df['dataset'] == 'Switzerland']

# Create a new CSV file
new_df3.to_csv('Switzerland_new_data.csv', index=False)

new_df4 = df[df['dataset'] == 'VA Long Beach']

# Create a new CSV file
new_df4.to_csv('VA Long Beach_new_data.csv', index=False)
